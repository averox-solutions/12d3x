"use strict";
(self.webpackChunkelement_web = self.webpackChunkelement_web || []).push([
    [5607], {
        "./src/async-components/structures/ErrorView.tsx": (e, r, t) => {
            t.d(r, {
                ErrorView: () => U,
                UnsupportedBrowserView: () => O
            });
            var l, n = t("./node_modules/react/index.js"),
                o = t("./node_modules/@vector-im/compound-web/dist/components/Typography/Heading.js"),
                a = t("./node_modules/@vector-im/compound-web/dist/components/Typography/Text.js"),
                i = t("./node_modules/@vector-im/compound-web/dist/components/Button/Button.js"),
                s = t("./node_modules/@vector-im/compound-web/dist/components/Separator/Separator.js"),
                c = t("./node_modules/@vector-im/compound-design-tokens/assets/web/icons/pop-out.js"),
                d = t("./src/SdkConfig.ts"),
                m = t("./src/components/utils/Flex.tsx"),
                p = t("./src/languageHandler.tsx");

            function u() {
                return u = Object.assign ? Object.assign.bind() : function (e) {
                    for (var r = 1; r < arguments.length; r++) {
                        var t = arguments[r];
                        for (var l in t)({}).hasOwnProperty.call(t, l) && (e[l] = t[l])
                    }
                    return e
                }, u.apply(null, arguments)
            }
            var v = function (e, r) {
                    return n.createElement("svg", u({
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 20 20",
                        role: "presentation",
                        "aria-hidden": !0,
                        ref: r
                    }, e), l || (l = n.createElement("path", {
                        fill: "#1B1D22",
                        fillRule: "evenodd",
                        d: "M13.416 2a3.4 3.4 0 0 1-.881 2.561c-.622.719-1.565 1.133-2.558 1.123-.063-.9.262-1.788.904-2.466A4.02 4.02 0 0 1 13.416 2m3.14 5.45c-1.143.653-1.846 1.802-1.863 3.047.002 1.409.91 2.68 2.307 3.228a7.8 7.8 0 0 1-1.2 2.27c-.707.98-1.448 1.94-2.624 1.958-.56.012-.937-.138-1.33-.293-.41-.163-.838-.332-1.508-.332-.71 0-1.156.175-1.587.343-.372.146-.733.287-1.241.306-1.12.039-1.976-1.048-2.709-2.02-1.464-1.986-2.604-5.597-1.075-8.054.717-1.197 2.06-1.957 3.534-2.001.636-.013 1.245.215 1.78.414.408.153.773.289 1.072.289.262 0 .617-.131 1.03-.283.651-.24 1.448-.534 2.26-.455 1.26.037 2.43.624 3.153 1.584",
                        clipRule: "evenodd"
                    })))
                },
                _ = (0, n.forwardRef)(v);
            var b;

            function g() {
                return g = Object.assign ? Object.assign.bind() : function (e) {
                    for (var r = 1; r < arguments.length; r++) {
                        var t = arguments[r];
                        for (var l in t)({}).hasOwnProperty.call(t, l) && (e[l] = t[l])
                    }
                    return e
                }, g.apply(null, arguments)
            }
            var w = function (e, r) {
                    return n.createElement("svg", g({
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 20 20",
                        role: "presentation",
                        "aria-hidden": !0,
                        ref: r
                    }, e), b || (b = n.createElement("path", {
                        fill: "#1B1D22",
                        d: "M10.491 2H18v7.509h-7.509zM2 10.49h7.509v7.509H2zM2 2h7.509v7.509H2zM10.491 10.49H18v7.509h-7.509z"
                    })))
                },
                h = (0, n.forwardRef)(w);
            var f, E;

            function k() {
                return k = Object.assign ? Object.assign.bind() : function (e) {
                    for (var r = 1; r < arguments.length; r++) {
                        var t = arguments[r];
                        for (var l in t)({}).hasOwnProperty.call(t, l) && (e[l] = t[l])
                    }
                    return e
                }, k.apply(null, arguments)
            }
            var x = function (e, r) {
                    return n.createElement("svg", k({
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 20 20",
                        role: "presentation",
                        "aria-hidden": !0,
                        ref: r
                    }, e), f || (f = n.createElement("g", {
                        fill: "#000",
                        clipPath: "url(#linux_svg__a)"
                    }, n.createElement("path", {
                        d: "M11.005 17.203a2.3 2.3 0 0 1-.914.207 2.34 2.34 0 0 1-1.306-.413 2.26 2.26 0 0 1-.583.834 2.3 2.3 0 0 1-.898.503h5.117a2.4 2.4 0 0 1-.826-.425 2.3 2.3 0 0 1-.59-.706M5.592 13.894a.2.2 0 0 0 .055-.025q.048-.409.108-.783a.95.95 0 0 1 .068-.413c.29-1.586.694-2.7 1.253-3.377a.108.108 0 0 1 .15-.015.102.102 0 0 1 .016.145q-.087.106-.17.227-.636.928-1 2.824h.026a.5.5 0 0 1 .138 0c.165.035.423.17.82.559.052-2.267 1.385-4.094 3.036-4.094 1.456 0 2.673 1.429 2.963 3.33.138-.267.36-.484.635-.618a.7.7 0 0 1 .212-.04 6.2 6.2 0 0 0-.79-1.95 3 3 0 0 0-.167-.227.1.1 0 0 1-.025-.076.1.1 0 0 1 .04-.069.1.1 0 0 1 .077-.023.1.1 0 0 1 .07.038c.424.52.776 1.297 1.038 2.351.565.206.58 1.135.593 1.89 0 .358 0 .73.086.825.087.095.271.074.53-.033.03-.328.044-.62.052-.864v-.902c0-2.063-2.721-5.63-2.721-5.63l-.316-2.68c0-2.461-2.277-2.439-2.277-2.439s-2.286-.022-2.286 2.428l-.305 2.692S4.78 10.509 4.78 12.574v.258s-.011.25 0 .64v.19c.345.127.698.261.812.232m4.49-8.676c.634.058 1.646.207 1.692.512.034.235-.357.685-.435.771-.164.18-.73.768-1.243.768-.512 0-1.08-.588-1.24-.768-.078-.086-.47-.536-.438-.771.038-.312 1.06-.454 1.663-.512"
                    }), n.createElement("path", {
                        d: "M10.093 7.062c.277 0 .702-.274 1.081-.697.29-.32.396-.555.387-.609-.053-.105-.745-.264-1.481-.334-.713.07-1.406.23-1.458.339.076.229.21.436.389.602.381.425.804.7 1.082.7M10.662 15.949c-.243-2.172-.019-2.622.172-2.77a.35.35 0 0 1 .334-.048c.192.093.36.227.489.392.24.254.406.413.56.326.111-.064.268-.412.424-.732.08-.171.163-.355.254-.53-.211-1.941-1.375-3.439-2.796-3.439-1.56 0-2.827 1.805-2.827 4.023v.08c.258.264.567.619.944 1.083q.222.272.406.571a2.26 2.26 0 0 1 .241 1.881c.356.26.786.405 1.23.413.285-.001.566-.06.825-.175a2 2 0 0 1-.133-.384 6 6 0 0 1-.123-.691"
                    }), n.createElement("path", {
                        d: "M8.043 14.459a18 18 0 0 0-.764-.893l-.108-.116-.11-.115c-.489-.495-.747-.631-.883-.654a.2.2 0 0 0-.057 0 .12.12 0 0 0-.095.068v.014a.76.76 0 0 0-.049.339v.272a.92.92 0 0 1-.125.602.3.3 0 0 1-.071.06l-.045.027a.5.5 0 0 1-.089.035h-.023c-.176.03-.461-.07-.823-.206l-.106-.041c-.453-.176-.982-.378-1.37-.378a.53.53 0 0 0-.46.194c-.285.412.35 1.06.863 1.584.315.324.563.578.59.767.049.351-.328.485-.66.605a1.3 1.3 0 0 0-.47.23c-.05.059-.049.098-.038.127.046.158.423.507 2.415 1.07q.33.093.67.149c.41.06.828.007 1.207-.152.38-.16.706-.42.942-.752q.138-.205.226-.435l.043-.101c0-.035.019-.074.03-.11A2.07 2.07 0 0 0 8.438 15a6 6 0 0 0-.396-.54M16.059 14.317a1.3 1.3 0 0 0-.504.155l-.23.097c-.255.095-.509.14-.674-.079a.5.5 0 0 1-.078-.19 3 3 0 0 1-.046-.493v-.268c0-.6-.022-1.322-.312-1.604a.42.42 0 0 0-.211-.116h-.032a.43.43 0 0 0-.212.029c-.25.099-.467.412-.658.78l-.09.18q-.052.104-.098.205c-.032.068-.06.126-.087.188-.186.413-.332.728-.502.825-.313.18-.586-.11-.825-.365a1.3 1.3 0 0 0-.4-.334.2.2 0 0 0-.063-.012.1.1 0 0 0-.07.024c-.132.103-.32.576-.094 2.587q.037.333.115.66.043.172.114.336.022.046.047.093c.017.03.027.062.044.093.173.314.425.58.733.773a2.2 2.2 0 0 0 2.086.143c.332-.15.62-.38.836-.667q.204-.27.375-.563c1.016-1.763 1.035-2.269.957-2.413a.13.13 0 0 0-.121-.064"
                    }))), E || (E = n.createElement("defs", null, n.createElement("clipPath", {
                        id: "linux_svg__a"
                    }, n.createElement("path", {
                        fill: "#fff",
                        d: "M2.639 1.825h14.445v16.508H2.639z"
                    })))))
                },
                y = (0, n.forwardRef)(x);
            const U = ({
                    title: e,
                    messages: r,
                    footer: t,
                    children: l
                }) => n.createElement("div", {
                    className: "mx_ErrorView cpd-theme-light"
                }, n.createElement("img", {
                    className: "mx_ErrorView_logo",
                    height: "360",
                    src: "https://firebasestorage.googleapis.com/v0/b/laaleh-2451e.appspot.com/o/beep.svg?alt=media&token=3847db46-30c6-4a1d-8ef4-58fbcbaa7835",
                    alt: "Beep Pakistan"
                }), n.createElement("div", {
                    className: "mx_ErrorView_container"
                }, n.createElement(o.D, {
                    size: "md",
                    weight: "semibold"
                }, e), null == r ? void 0 : r.map((e => n.createElement(a.E, {
                    key: e,
                    size: "lg"
                }, e))), l), t),
                j = ({
                    appleAppStoreUrl: e,
                    googlePlayUrl: r,
                    fdroidUrl: t
                }) => n.createElement(m.s, {
                    gap: "var(--cpd-space-6x)"
                }, e && n.createElement("a", {
                    href: e,
                    target: "_blank",
                    rel: "noreferrer noopener"
                }, n.createElement("img", {
                    height: "64",
                    src: "themes/element/img/download/apple.svg",
                    alt: "Apple App Store"
                })), r && n.createElement("a", {
                    href: r,
                    target: "_blank",
                    rel: "noreferrer noopener",
                    key: "android"
                }, n.createElement("img", {
                    height: "64",
                    src: "themes/element/img/download/google.svg",
                    alt: "Google Play Store"
                })), t && n.createElement("a", {
                    href: t,
                    target: "_blank",
                    rel: "noreferrer noopener",
                    key: "fdroid"
                }, n.createElement("img", {
                    height: "64",
                    src: "themes/element/img/download/fdroid.svg",
                    alt: "F-Droid"
                }))),
                z = ({
                    macOsUrl: e,
                    win64Url: r,
                    win32Url: t,
                    linuxUrl: l
                }) => n.createElement(m.s, {
                    gap: "var(--cpd-space-4x)"
                }, e && n.createElement(i.$, {
                    as: "a",
                    href: e,
                    kind: "secondary",
                    Icon: _
                }, (0, p._t)("incompatible_browser|macos")), r && n.createElement(i.$, {
                    as: "a",
                    href: r,
                    kind: "secondary",
                    Icon: h
                }, (0, p._t)("incompatible_browser|windows", {
                    bits: "64"
                })), t && n.createElement(i.$, {
                    as: "a",
                    href: t,
                    kind: "secondary",
                    Icon: h
                }, (0, p._t)("incompatible_browser|windows", {
                    bits: "32"
                })), l && n.createElement(i.$, {
                    as: "a",
                    href: l,
                    kind: "secondary",
                    Icon: y
                }, (0, p._t)("incompatible_browser|linux"))),
                M = e => r => n.createElement("a", {
                    href: e,
                    target: "_blank",
                    rel: "noreferrer noopener"
                }, r),
                O = ({
                    onAccept: e
                }) => {
                    var r, t, l, u, v, _, b, g, w, h, f, E, k, x, y, O, A, B, S;
                    const q = d.Ay.get(),
                        P = null !== (r = q.brand) && void 0 !== r ? r : "Element",
                        H = (null === (t = q.desktop_builds) || void 0 === t ? void 0 : t.available) && ((null === (l = q.desktop_builds) || void 0 === l ? void 0 : l.url_macos) || (null === (u = q.desktop_builds) || void 0 === u ? void 0 : u.url_win64) || (null === (v = q.desktop_builds) || void 0 === v ? void 0 : v.url_win32) || (null === (_ = q.desktop_builds) || void 0 === _ ? void 0 : _.url_linux)),
                        V = Boolean((null === (b = q.mobile_builds) || void 0 === b ? void 0 : b.ios) || (null === (g = q.mobile_builds) || void 0 === g ? void 0 : g.android) || (null === (w = q.mobile_builds) || void 0 === w ? void 0 : w.fdroid));
                    return n.createElement(U, {
                        title: (0, p._t)("incompatible_browser|title", {
                            brand: P
                        }),
                        messages: [(0, p._t)("incompatible_browser|description", {
                            brand: P,
                            detail: e ? (0, p._t)("incompatible_browser|detail_can_continue") : (0, p._t)("incompatible_browser|detail_no_continue")
                        })],
                        footer: n.createElement(n.Fragment, null, (H || V) && n.createElement(s.w, null), H && n.createElement(n.Fragment, null, n.createElement(o.D, {
                            as: "h2",
                            size: "sm",
                            weight: "semibold"
                        }, (0, p._t)("incompatible_browser|use_desktop_heading", {
                            brand: P
                        })), n.createElement(z, {
                            macOsUrl: null === (h = q.desktop_builds) || void 0 === h ? void 0 : h.url_macos,
                            win64Url: null === (f = q.desktop_builds) || void 0 === f ? void 0 : f.url_win64,
                            win32Url: null === (E = q.desktop_builds) || void 0 === E ? void 0 : E.url_win32,
                            linuxUrl: null === (k = q.desktop_builds) || void 0 === k ? void 0 : k.url_linux
                        })), V && n.createElement(n.Fragment, null, n.createElement(o.D, {
                            as: "h2",
                            size: "sm",
                            weight: "semibold"
                        }, H ? (0, p._t)("incompatible_browser|use_mobile_heading_after_desktop") : (0, p._t)("incompatible_browser|use_mobile_heading", {
                            brand: P
                        })), n.createElement(j, {
                            appleAppStoreUrl: null !== (x = null === (y = q.mobile_builds) || void 0 === y ? void 0 : y.ios) && void 0 !== x ? x : void 0,
                            googlePlayUrl: null !== (O = null === (A = q.mobile_builds) || void 0 === A ? void 0 : A.android) && void 0 !== O ? O : void 0,
                            fdroidUrl: null !== (B = null === (S = q.mobile_builds) || void 0 === S ? void 0 : S.fdroid) && void 0 !== B ? B : void 0
                        })))
                    }, n.createElement(a.E, {
                        size: "lg"
                    }, (0, p._t)("incompatible_browser|supported_browsers", {}, {
                        Chrome: M("https://google.com/chrome"),
                        Firefox: M("https://firefox.com"),
                        Edge: M("https://microsoft.com/edge"),
                        Safari: M("https://apple.com/safari")
                    })), n.createElement(m.s, {
                        gap: "var(--cpd-space-4x)",
                        className: "mx_ErrorView_buttons"
                    }, n.createElement(i.$, {
                        Icon: c.A,
                        kind: "secondary",
                        size: "sm"
                    }, (0, p._t)("incompatible_browser|learn_more")), e && n.createElement(i.$, {
                        kind: "primary",
                        size: "sm",
                        onClick: e
                    }, (0, p._t)("incompatible_browser|continue"))))
                }
        }
    }
]);
//# sourceMappingURL=error-view.js.map
