(() => {
    var e = {
            "./node_modules/loglevel/lib/loglevel.js": function (e, t, n) {
                var o, r;
                ! function () {
                    "use strict";
                    o = function () {
                        var e = function () {},
                            t = "undefined",
                            n = typeof window !== t && typeof window.navigator !== t && /Trident\/|MSIE /.test(window.navigator.userAgent),
                            o = ["trace", "debug", "info", "warn", "error"],
                            r = {},
                            i = null;

                        function a(e, t) {
                            var n = e[t];
                            if ("function" == typeof n.bind) return n.bind(e);
                            try {
                                return Function.prototype.bind.call(n, e)
                            } catch (t) {
                                return function () {
                                    return Function.prototype.apply.apply(n, [e, arguments])
                                }
                            }
                        }

                        function c() {
                            console.log && (console.log.apply ? console.log.apply(console, arguments) : Function.prototype.apply.apply(console.log, [console, arguments])), console.trace && console.trace()
                        }

                        function l(o) {
                            return "debug" === o && (o = "log"), typeof console !== t && ("trace" === o && n ? c : void 0 !== console[o] ? a(console, o) : void 0 !== console.log ? a(console, "log") : e)
                        }

                        function s() {
                            for (var n = this.getLevel(), r = 0; r < o.length; r++) {
                                var i = o[r];
                                this[i] = r < n ? e : this.methodFactory(i, n, this.name)
                            }
                            if (this.log = this.debug, typeof console === t && n < this.levels.SILENT) return "No console available for logging"
                        }

                        function u(e) {
                            return function () {
                                typeof console !== t && (s.call(this), this[e].apply(this, arguments))
                            }
                        }

                        function d(e, t, n) {
                            return l(e) || u.apply(this, arguments)
                        }

                        function f(e, n) {
                            var a, c, l, u = this,
                                f = "loglevel";

                            function p(e) {
                                var n = (o[e] || "silent").toUpperCase();
                                if (typeof window !== t && f) {
                                    try {
                                        return void(window.localStorage[f] = n)
                                    } catch (e) {}
                                    try {
                                        window.document.cookie = encodeURIComponent(f) + "=" + n + ";"
                                    } catch (e) {}
                                }
                            }

                            function y() {
                                var e;
                                if (typeof window !== t && f) {
                                    try {
                                        e = window.localStorage[f]
                                    } catch (e) {}
                                    if (typeof e === t) try {
                                        var n = window.document.cookie,
                                            o = encodeURIComponent(f),
                                            r = n.indexOf(o + "="); - 1 !== r && (e = /^([^;]+)/.exec(n.slice(r + o.length + 1))[1])
                                    } catch (e) {}
                                    return void 0 === u.levels[e] && (e = void 0), e
                                }
                            }

                            function w() {
                                if (typeof window !== t && f) {
                                    try {
                                        window.localStorage.removeItem(f)
                                    } catch (e) {}
                                    try {
                                        window.document.cookie = encodeURIComponent(f) + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC"
                                    } catch (e) {}
                                }
                            }

                            function v(e) {
                                var t = e;
                                if ("string" == typeof t && void 0 !== u.levels[t.toUpperCase()] && (t = u.levels[t.toUpperCase()]), "number" == typeof t && t >= 0 && t <= u.levels.SILENT) return t;
                                throw new TypeError("log.setLevel() called with invalid level: " + e)
                            }
                            "string" == typeof e ? f += ":" + e : "symbol" == typeof e && (f = void 0), u.name = e, u.levels = {
                                TRACE: 0,
                                DEBUG: 1,
                                INFO: 2,
                                WARN: 3,
                                ERROR: 4,
                                SILENT: 5
                            }, u.methodFactory = n || d, u.getLevel = function () {
                                return null != l ? l : null != c ? c : a
                            }, u.setLevel = function (e, t) {
                                return l = v(e), !1 !== t && p(l), s.call(u)
                            }, u.setDefaultLevel = function (e) {
                                c = v(e), y() || u.setLevel(e, !1)
                            }, u.resetLevel = function () {
                                l = null, w(), s.call(u)
                            }, u.enableAll = function (e) {
                                u.setLevel(u.levels.TRACE, e)
                            }, u.disableAll = function (e) {
                                u.setLevel(u.levels.SILENT, e)
                            }, u.rebuild = function () {
                                if (i !== u && (a = v(i.getLevel())), s.call(u), i === u)
                                    for (var e in r) r[e].rebuild()
                            }, a = v(i ? i.getLevel() : "WARN");
                            var g = y();
                            null != g && (l = v(g)), s.call(u)
                        }(i = new f).getLogger = function (e) {
                            if ("symbol" != typeof e && "string" != typeof e || "" === e) throw new TypeError("You must supply a name when creating a logger.");
                            var t = r[e];
                            return t || (t = r[e] = new f(e, i.methodFactory)), t
                        };
                        var p = typeof window !== t ? window.log : void 0;
                        return i.noConflict = function () {
                            return typeof window !== t && window.log === i && (window.log = p), i
                        }, i.getLoggers = function () {
                            return r
                        }, i.default = i, i
                    }, void 0 === (r = "function" == typeof o ? o.call(t, n, t, e) : o) || (e.exports = r)
                }()
            }
        },
        t = {};

    function n(o) {
        var r = t[o];
        if (void 0 !== r) return r.exports;
        var i = t[o] = {
            exports: {}
        };
        return e[o].call(i.exports, i, i.exports, n), i.exports
    }
    n.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return n.d(t, {
            a: t
        }), t
    }, n.d = (e, t) => {
        for (var o in t) n.o(t, o) && !n.o(e, o) && Object.defineProperty(e, o, {
            enumerable: !0,
            get: t[o]
        })
    }, n.g = function () {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), n.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), (() => {
        if (void 0 !== n) {
            var e = n.u,
                t = n.e,
                o = {},
                r = {};
            n.u = function (t) {
                return e(t) + (o.hasOwnProperty(t) ? "?" + o[t] : "")
            }, n.e = function (i) {
                return t(i).catch((function (t) {
                    var a = r.hasOwnProperty(i) ? r[i] : 3;
                    if (a < 1) {
                        var c = e(i);
                        throw t.message = "Beep Pakistan", t.request = c, t
                    }
                    return new Promise((function (e) {
                        setTimeout((function () {
                            var t = Date.now();
                            o[i] = t, r[i] = a - 1, e(n.e(i))
                        }), 500)
                    }))
                }))
            }
        }
    })(), (() => {
        "use strict";

        function e() {
            try {
                var e;
                return null !== (e = self) && void 0 !== e && e.indexedDB ? self.indexedDB : window.indexedDB
            } catch {}
        }
        let t = null;
        async function o() {
            if (!e()) throw new Error("IndexedDB not available");
            t = await new Promise(((t, n) => {
                const o = e().open("matrix-react-sdk", 1);
                o.onerror = n, o.onsuccess = () => {
                    t(o.result)
                }, o.onupgradeneeded = () => {
                    const e = o.result;
                    e.createObjectStore("pickleKey"), e.createObjectStore("account")
                }
            }))
        }
        async function r(e, n, r) {
            return t || await o(), new Promise(((o, i) => {
                const a = t.transaction([e], n);
                a.onerror = i;
                const c = a.objectStore(e),
                    l = r(c);
                l.onerror = i, l.onsuccess = () => {
                    o(l.result)
                }
            }))
        }
        async function i(e, n) {
            return t || await o(), r(e, "readonly", (e => e.get(n)))
        }
        var a = n("./node_modules/loglevel/lib/loglevel.js"),
            c = n.n(a);
        const l = "matrix";

        function s(e) {
            const t = e;
            t.getChild = t.withPrefix = function (e) {
                return function (e) {
                    const t = c().getLogger(`${l}-${e}`);
                    t.prefix !== e && (s(t), t.prefix = e, t.setLevel(c().levels.DEBUG, !1));
                    return t
                }((this.prefix || "") + e)
            }
        }
        c().methodFactory = function (e, t, n) {
            return function (...t) {
                this.prefix && t.unshift(this.prefix);
                return "error" === e || "warn" === e || "trace" === e || "info" === e || "debug" === e ? console[e](...t) : console.log(...t)
            }
        };
        const u = c().getLogger(l);
        u.setLevel(c().levels.DEBUG, !1), s(u);

        function d(e, t) {
            if ("function" == typeof e.toBase64) return e.toBase64(t);
            let n = btoa(e.reduce(((e, t) => e + String.fromCharCode(t)), ""));
            return t.omitPadding && (n = n.replace(/={1,2}$/, "")), "base64url" === t.alphabet && (n = n.replace(/\+/g, "-").replace(/\//g, "_")), n
        }

        function f(e) {
            return function (e, t) {
                return "function" == typeof Uint8Array.fromBase64 ? Uint8Array.fromBase64(e, t) : Uint8Array.from(atob(e), (e => e.charCodeAt(0)))
            }(e.replace(/-/g, "+").replace(/_/g, "/"), {
                alphabet: "base64",
                lastChunkHandling: "loose"
            })
        }
        const p = new Uint8Array(8);
        async function y(e, t, n) {
            const [o, r] = await async function (e, t) {
                const n = await globalThis.crypto.subtle.importKey("raw", e, {
                        name: "HKDF"
                    }, !1, ["deriveBits"]),
                    o = await globalThis.crypto.subtle.deriveBits({
                        name: "HKDF",
                        salt: p,
                        info: (new TextEncoder).encode(t),
                        hash: "SHA-256"
                    }, n, 512),
                    r = o.slice(0, 32),
                    i = o.slice(32),
                    a = globalThis.crypto.subtle.importKey("raw", r, {
                        name: "AES-CTR"
                    }, !1, ["encrypt", "decrypt"]),
                    c = globalThis.crypto.subtle.importKey("raw", i, {
                        name: "HMAC",
                        hash: {
                            name: "SHA-256"
                        }
                    }, !1, ["sign", "verify"]);
                return Promise.all([a, c])
            }(t, n), i = f(e.ciphertext);
            if (!await globalThis.crypto.subtle.verify({
                    name: "HMAC"
                }, r, f(e.mac), i)) throw new Error(`Error decrypting secret ${n}: bad MAC`);
            const a = await globalThis.crypto.subtle.decrypt({
                name: "AES-CTR",
                counter: f(e.iv),
                length: 64
            }, o, i);
            return (new TextDecoder).decode(new Uint8Array(a))
        }
        const w = "access_token";
        async function v(e) {
            const t = new Uint8Array(e.length);
            for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
            const n = await crypto.subtle.importKey("raw", t, "HKDF", !1, ["deriveBits"]);
            return t.fill(0), new Uint8Array(await crypto.subtle.deriveBits({
                name: "HKDF",
                hash: "SHA-256",
                salt: new Uint8Array(32),
                info: new Uint8Array(0)
            }, n, 256))
        }

        function g(e, t) {
            const n = new Uint8Array(e.length + t.length + 1);
            for (let t = 0; t < e.length; t++) n[t] = e.charCodeAt(t);
            n[e.length] = 124;
            for (let o = 0; o < t.length; o++) n[e.length + 1 + o] = t.charCodeAt(o);
            return n
        }
        async function h(e, t, n) {
            var o;
            if (null !== (o = crypto) && void 0 !== o && o.subtle && (e && e.encrypted && e.iv && e.cryptoKey)) try {
                const o = g(t, n),
                    r = await crypto.subtle.decrypt({
                        name: "AES-GCM",
                        iv: e.iv,
                        additionalData: o
                    }, e.cryptoKey, e.encrypted);
                if (r) return d(new Uint8Array(r), {
                    alphabet: "base64",
                    omitPadding: !0
                })
            } catch {
                u.error("Error decrypting pickle key")
            }
        }
        const m = {};

        function b(e) {
            if (e) return {
                headers: {
                    Authorization: `Bearer ${e}`
                }
            }
        }
        n.g.addEventListener("install", (e => {
            e.waitUntil(skipWaiting())
        })), n.g.addEventListener("activate", (e => {
            e.waitUntil(clients.claim())
        })), n.g.addEventListener("fetch", (e => {
            if ("GET" !== e.request.method) return;
            const t = new URL(e.request.url);
            (t.pathname.startsWith("/_matrix/media/v3/download") || t.pathname.startsWith("/_matrix/media/v3/thumbnail")) && e.respondWith((async o => {
                let r;
                try {
                    const o = t.origin;
                    await new Promise((e => setTimeout((() => e()), 10 * Math.random())));
                    const a = await n.g.clients.get(e.clientId);
                    r = await async function (e) {
                        const t = await i("account", "mx_access_token"),
                            {
                                userId: o,
                                deviceId: r,
                                homeserver: a
                            } = await async function (e) {
                                return new Promise(((t, o) => {
                                    const r = setTimeout((() => o(new Error("timeout in postMessage"))), 1e3),
                                        i = Math.random().toString(36),
                                        a = e => {
                                            var o;
                                            (null === (o = e.data) || void 0 === o ? void 0 : o.responseKey) === i && (clearTimeout(r), t(e.data), n.g.removeEventListener("message", a))
                                        };
                                    n.g.addEventListener("message", a), e.postMessage({
                                        responseKey: i,
                                        type: "userinfo"
                                    })
                                }))
                            }(e), c = await i("pickleKey", [o, r]);
                        if (c && (!c.encrypted || !c.iv || !c.cryptoKey)) throw new Error("SW: Invalid pickle key loaded - ignoring");
                        try {
                            const e = await h(c, o, r),
                                n = await async function (e, t, n) {
                                    if ("string" == typeof t) return t;
                                    if (!e) throw new Error(`Error decrypting secret ${n}: no pickle key found.`);
                                    const o = await v(e),
                                        r = await y(t, o, n);
                                    return o.fill(0), r
                                }(e, t, w);
                            return {
                                accessToken: n,
                                homeserver: a
                            }
                        } catch (e) {
                            throw new Error("SW: Error decrypting access token.", {
                                cause: e
                            })
                        }
                    }(a);
                    if (!(t.origin === new URL(r.homeserver).origin)) throw new Error("Request appears to be for media endpoint but wrong homeserver!");
                    await async function (e, t) {
                        var n, o;
                        if ((null === (n = m[e]) || void 0 === n ? void 0 : n.cacheExpiryTimeMs) > (new Date).getTime()) return;
                        const r = b(t),
                            i = await (await fetch(`${e}/_matrix/client/versions`, r)).json();
                        console.log(`[ServiceWorker] /versions response for '${e}': ${JSON.stringify(i)}`), m[e] = {
                            supportsAuthedMedia: Boolean(null == i || null === (o = i.versions) || void 0 === o ? void 0 : o.includes("v1.11")),
                            cacheExpiryTimeMs: (new Date).getTime() + 72e5
                        }, console.log(`[ServiceWorker] serverSupportMap update for '${e}': ${JSON.stringify(m[e])}`)
                    }(o, r.accessToken), m[o].supportsAuthedMedia && r.accessToken && (t.href = t.href.replace(/\/media\/v3\/(.*)\//, "/client/v1/media/$1/"))
                } catch (e) {
                    r = void 0, console.error("SW: Error in request rewrite.", e)
                }
                return fetch(t, b(null === (o = r) || void 0 === o ? void 0 : o.accessToken))
            })())
        }))
    })()
})();
//# sourceMappingURL=sw.js.map
